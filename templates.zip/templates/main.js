function fonction() {
    console.log("enculé")
    fetch('donnees_tamagotchi.json')
  .then(response => response.json())
  .then(data => {
    console.log(data);
    // Utilisez les données ici
  })
  .catch(error => console.error('Erreur:', error));
}